import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;


public class test {
public static void main(String[] args) throws IOException {
	ArrayList<Integer> data= new ArrayList<Integer>();
//	System.out.println(data.get(0));
	
//	data= new ArrayList<Integer>();
	String currentLine = "";
	FileReader fileReader = new FileReader("fakeData.csv");
	BufferedReader br = new BufferedReader(fileReader);
	while((currentLine = br.readLine()) != null){
		if(currentLine.isEmpty())
			data.add(0);
		else 
		data.add(Integer.parseInt(currentLine));
	}
//	for(int i=0; i<data.size(); i++){
//		if(data.get(i).isEmpty()){
//			System.out.println("ana empty   " + i );
//		}
//	}
	System.out.println(data.get(0));
	System.out.println(data.get(1));
	System.out.println(data.get(2));
	System.out.println(data.get(3));
	}
}
