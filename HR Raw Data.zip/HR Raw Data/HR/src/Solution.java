public class Solution {
   static public int titleToNumber(String s) {
     
        int size = s.length(); 
        int ret=0; 
        String ss = s.toLowerCase();

        
        if (size==1)
        	return ss.charAt(0) -'a' +1;
        else {
        	ret+=ss.charAt(size-1) -'a' +1;
        	size--; 
//        	for (int i=(size-1); i>-1; i--){
//                int a = ss.charAt(size-1)-'a'+1 ;
                int ll= (int) Math.pow(26, size) ;
                  ret+=ll;
//              }	
        }
        
        return ret; 
        
    }
    
    public static void main(String[] args) {
	System.out.println(titleToNumber("aaa"));
   }
}